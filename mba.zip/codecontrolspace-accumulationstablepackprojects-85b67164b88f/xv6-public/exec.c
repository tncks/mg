#include "types.h"
#include "spinlock.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "defs.h"
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
  char *s, *last;
  int i, off;
  uint argc, sp, ustack[3+MAXARG+1], bstack, theap;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;

//#ifdef D_exec
  if(!(proc->pid==1 || proc->pid==2))  
    cprintf("[exec] pid %d exec call .. path: [%s]\n", proc->pid, path);
//#endif
  // To prevent multiple threads clear other PCB, enable interrupt.   
  //pushcli();
  if(isLWP(proc) == 1){
//#ifdef D_exec
    cprintf("[exec] call ExitLWP(1) pid :%d, path: [%s]\n", proc->pid, path);
//#endif
    // choose either ExitLWP or kill_except during the test (two logics are very different)
    ExitLWP(1); // <- if choose this code, use only this line
    //kill_except(proc->pid, proc); // <- if choose this code, disable above one line code and use this 
  }
  //popcli();
//#ifdef D_exec
  if(!(proc->pid==1 || proc->pid==2))  
    cprintf("[exec] ExitLWP done pid :%d, path: [%s]\n", proc->pid, path );
//#endif
  
  begin_op();
    
  if((ip = namei(path)) == 0){
    end_op();
    return -1;
  }
  ilock(ip);
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
    goto bad;
  if(elf.magic != ELF_MAGIC)
    goto bad;

  if((pgdir = setupkvm()) == 0)
    goto bad;

  // Load program into memory.
  if(!(proc->pid==1 || proc->pid==2))  
    cprintf("[pid %d] -> Load '%s' program into memory ( exec.c ), path: [%s]\n", proc->pid, path, path); // debug 
  theap = 0;
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
      goto bad;
    if(ph.type != ELF_PROG_LOAD)
      continue;
    if(ph.memsz < ph.filesz)
      goto bad;
    if(ph.vaddr + ph.memsz < ph.vaddr)
      goto bad;
    if((theap = allocuvm(pgdir, theap, ph.vaddr + ph.memsz)) == 0)
      goto bad;
    if(ph.vaddr % PGSIZE != 0)
      goto bad;
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
      goto bad;
  }
  iunlockput(ip);
  end_op();
  ip = 0;

  // Allocate two pages at the next page boundary.
  // Make the first inaccessible.  Use the second as the user stack.
  bstack = KERNBASE - 1;
  bstack = PGROUNDDOWN(bstack);
  bstack = bstack - 2*PGSIZE;
  if((sp = allocuvm(pgdir, bstack, bstack + 2*PGSIZE)) == 0)
    goto bad;
  clearpteu(pgdir, (char*)(sp - 2*PGSIZE));
  //sp = sz;

  // Push argument strings, prepare rest of stack in ustack.
  for(argc = 0; argv[argc]; argc++) {
    if(argc >= MAXARG)
      goto bad;
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
      goto bad;
    ustack[3+argc] = sp;
  }
  ustack[3+argc] = 0;

  ustack[0] = 0xffffffff;  // fake return PC
  ustack[1] = argc;
  ustack[2] = sp - (argc+1)*4;  // argv pointer

  sp -= (3+argc+1) * 4;
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
    goto bad;

  // Save program name for debugging.
  for(last=s=path; *s; s++)
    if(*s == '/')
      last = s+1;
  safestrcpy(proc->name, last, sizeof(proc->name));


  // version 1 <- current valid? under tested (sjlov17)
  // Commit to the user image.
  oldpgdir = proc->pgdir;
  proc->pgdir = pgdir;
  proc->sz = KERNBASE - PGSIZE;
  proc->theap = theap;
  proc->bstack = bstack;
  proc->tf->eip = elf.entry;  // main
  proc->tf->esp = sp;
  switchuvm(proc);

  if(isLWP(proc) == 0)
    freevm(oldpgdir);
  /* below: is valid logic? need test ...  */
  // focusing: pseudo-code algorithm logic here:
  //if(HaveThread(proc) == 1) // <- umm. not recommend (optional test need)
  //  ExitAllLWP(1); // then do either this line or next line 
  // //or
  // wakeup_except(proc->pid, proc); // <- added newly (maybe valid logic) but under test now.
  // test one by one. need test, wakeup_except is highly need test. do test right now!!.
  return 0; // be careful: under the bad -> wakeup_except one line also should be cared too.

 bad:
  if(pgdir)
    freevm(pgdir);
  if(ip){
    iunlockput(ip);
    end_op();
  }
  // wakeup_except(proc->pid, proc);
  return -1;
  // end of version 1.

  // version 2 <- need to inspect now 
  /*
 // Commit to the user image.
  oldpgdir = curproc->pgdir;
  curproc->pgdir = pgdir;
  curproc->sz = sz;

  for (t = curproc->threads; t < &curproc->threads[NTHREAD]; ++t) {
    off = t - curproc->threads;
    if (off == curproc->tidx) {
      // Update eip and esp of current thread.
      t->tf->eip = elf.entry;
      t->tf->esp = sp;
      curproc->ustacks[off] = sz;
      continue;
    }

    // Free other threads.
    if (curproc->kstacks[off] != 0) {
      kfree(curproc->kstacks[off]);
      curproc->kstacks[off] = 0;
      curproc->ustacks[off] = 0;
    }

    t->kstack = 0;
    t->state = UNUSED;
    t->tid = 0;
  }

  switchuvm(curproc);
  freevm(oldpgdir);
  return 0;

 bad:
  if(pgdir)
    freevm(pgdir);
  if(ip){
    iunlockput(ip);
    end_op();
  }
  return -1;
  */
  // end of version 2
}


/*

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
//#include "spinlock.h"
#include "proc.h"
#include "defs.h"
#include "x86.h"
#include "elf.h"

int
exec(char *path, char **argv)
{
  char *s, *last;
  int i, off, alive;
  uint argc, sz, sp, ustack[3+MAXARG+1];
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pde_t *pgdir, *oldpgdir;
  struct proc *curproc = myproc();
  struct proc *p;

  
  // Kill all other threads in the process
  acquire(&ptable.lock);

  if(curproc->killed){
    release(&ptable.lock);
    return -1;
  }

  if(curproc != curproc->process){
    curproc->threadcount = curproc->process->threadcount;
    curproc->process->threadcount = 0;
    curproc->process->pid = curproc->pid;
    curproc->pid = curproc->tgid;
    curproc->process = curproc;
  }

  for (p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
    if (p->tgid == curproc->tgid && p->pid != curproc->pid) {
      p->killed = 1;
      p->process = curproc;
      if (p->state == SLEEPING) 
        p->state = RUNNABLE;
    }
  }
  release(&ptable.lock);

  // Wait for them to die
  acquire(&ptable.lock);
  for (;;) {
    alive = 0;
    for (p = ptable.proc; p < &ptable.proc[NPROC]; p++) {
      // assumption: wait() will clear PID, TID
      if (p->tgid == curproc->tgid && p != curproc 
                                   && p->state != ZOMBIE) {
        alive = 1;
	break;
      }
    }
    if (alive) {
      sleep(curproc->process, &ptable.lock);
    }
    else {
      break;
    }
  }
  release(&ptable.lock);

  begin_op();

  if((ip = namei(path)) == 0){
    end_op();
    cprintf("exec: fail\n");
    return -1;
  }
  ilock(ip);
  pgdir = 0;

  // Check ELF header
  if(readi(ip, (char*)&elf, 0, sizeof(elf)) != sizeof(elf))
    goto bad;
  if(elf.magic != ELF_MAGIC)
    goto bad;

  if((pgdir = setupkvm()) == 0)
    goto bad;

  // Load program into memory.
  sz = 0;
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    if(readi(ip, (char*)&ph, off, sizeof(ph)) != sizeof(ph))
      goto bad;
    if(ph.type != ELF_PROG_LOAD)
      continue;
    if(ph.memsz < ph.filesz)
      goto bad;
    if(ph.vaddr + ph.memsz < ph.vaddr)
      goto bad;
    if((sz = allocuvm(pgdir, sz, ph.vaddr + ph.memsz)) == 0)
      goto bad;
    if(ph.vaddr % PGSIZE != 0)
      goto bad;
    if(loaduvm(pgdir, (char*)ph.vaddr, ip, ph.off, ph.filesz) < 0)
      goto bad;
  }
  iunlockput(ip);
  end_op();
  ip = 0;

  // Allocate two pages at the next page boundary.
  // Make the first inaccessible.  Use the second as the user stack.
  sz = PGROUNDUP(sz);
  if((sz = allocuvm(pgdir, sz, sz + 2*PGSIZE)) == 0)
    goto bad;
  clearpteu(pgdir, (char*)(sz - 2*PGSIZE));
  sp = sz;

  // Push argument strings, prepare rest of stack in ustack.
  for(argc = 0; argv[argc]; argc++) {
    if(argc >= MAXARG)
      goto bad;
    sp = (sp - (strlen(argv[argc]) + 1)) & ~3;
    if(copyout(pgdir, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
      goto bad;
    ustack[3+argc] = sp;
  }
  ustack[3+argc] = 0;

  ustack[0] = 0xffffffff;  // fake return PC
  ustack[1] = argc;
  ustack[2] = sp - (argc+1)*4;  // argv pointer

  sp -= (3+argc+1) * 4;
  if(copyout(pgdir, sp, ustack, (3+argc+1)*4) < 0)
    goto bad;

  // Save program name for debugging.
  for(last=s=path; *s; s++)
    if(*s == '/')
      last = s+1;
  safestrcpy(curproc->name, last, sizeof(curproc->name));

  initlock(&curproc->vlock, "valock");

  // Commit to the user image.

  acquire(&curproc->vlock);
  oldpgdir = curproc->pgdir;
  curproc->pgdir = pgdir;
  curproc->sz = sz;
  release(&curproc->vlock);

  curproc->tf->eip = elf.entry;  // main
  curproc->tf->esp = sp;
  switchuvm(curproc);
  freevm(oldpgdir);
  return 0;

 bad:
  if(pgdir)
    freevm(pgdir);
  if(ip){
    iunlockput(ip);
    end_op();
  }
  return -1;
} */
